import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import http from "node:http";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { gzipSync } from "node:zlib";
import {
  atomicWrite,
  captureId as newCaptureId,
  retainCapture,
} from "../../tooling/capture/captures.mjs";
import {
  acquireRunLock,
  closeWorkers,
  fetchBody,
  gitMetadata,
  hostMetadata,
  runClosedLoopPhase,
  runOpenLoopPhase,
  spawnWorkers,
  startServer,
  stopServer,
  waitForHealth,
} from "../../tooling/load/driver.mjs";
import { isShowcase, showcasePath } from "../rendering/showcase/admission.mjs";
import {
  buildAll,
  buildProa,
  environment,
  here,
  root,
  targetDirectory,
} from "./build.ts";
import contract from "./contract.json";
import {
  negativeControlsFor,
  sha256,
  validateSemanticHtml,
} from "./parity.mjs";
import {
  type Capture,
  type Phase,
  renderReport,
  validateResult,
} from "./report.ts";
import { frameworkSourceFiles } from "./sources.ts";

if (!globalThis.Bun || Bun.version !== "1.4.2")
  throw new Error("Use Bun 1.4.2");
const smoke = process.argv.includes("--smoke");
const parityOnly = process.argv.includes("--parity-only");
const noBuild = process.argv.includes("--no-build");
const proaOnly = process.argv.includes("--proa-only");
const selectedEngines = proaOnly ? ["proa"] : contract.engines;
if (proaOnly && smoke)
  throw new Error("Proa-only diagnostics use full sampling; omit --smoke");
const argument = (name: string, fallback: string) => {
  const i = process.argv.indexOf(name);
  if (i < 0) return fallback;
  assert.ok(
    process.argv[i + 1] && !process.argv[i + 1].startsWith("--"),
    `${name} requires a value`,
  );
  return process.argv[i + 1];
};
const shardWorkload = argument("--shard-workload", "");
if (shardWorkload)
  assert.ok(
    !proaOnly && contract.workloads.some((w) => w.id === shardWorkload),
    "Choose one known workload with the full framework cohort",
  );
const activeWorkloads = contract.workloads.filter(
  (w) => !shardWorkload || w.id === shardWorkload,
);
const resultsDirectory = shardWorkload
  ? join(here, "results/shards", shardWorkload)
  : join(here, "results");
const policy = smoke
  ? {
      ...contract.publication,
      repeats: 1,
      concurrency: 2,
      warmupRequests: 2,
      preRollSeconds: 0.2,
      // Leave room for the largest native pages to complete a full batch.
      // These diagnostic samples are never used for publication.
      durationSeconds: 10,
    }
  : contract.publication;
const output = resolve(
  argument(
    "--out",
    join(resultsDirectory, smoke ? "smoke.json" : "latest.json"),
  ),
);
assert.ok(output.endsWith(".json"), "Capture output must end in .json");
if (smoke && output === join(here, "results/latest.json"))
  throw new Error("Smoke captures cannot replace latest.json");
if (
  proaOnly &&
  (!process.argv.includes("--out") ||
    output === join(here, "results/latest.json"))
)
  throw new Error(
    "Proa-only diagnostics require an explicit non-publication --out path",
  );
const workersCount = Number(argument("--workers", "8"));
const headers = {
  accept: "text/html",
  "accept-encoding": "identity",
  "cache-control": "no-store",
};
const sourceFiles = frameworkSourceFiles(root);
const release = await acquireRunLock(root, "framework-ssr");
let workers: Awaited<ReturnType<typeof spawnWorkers>> | undefined;
const agent = new http.Agent({ keepAlive: true, maxSockets: 16 });
const labels: Record<string, string> = {
  proa: "Proa",
  exact: "Exact",
  nextjs: "Next.js",
  astro: "Astro",
  sveltekit: "SvelteKit",
  leptos: "Leptos",
};
const portFor = (id: string) => 16230 + contract.engines.indexOf(id);
const workloadPath = (id: string) =>
  isShowcase(id) ? showcasePath(id) : `/${id}`;
const nativeEngine = (id: string) => id === "proa" || id === "leptos";
function serverFor(id: string, workload: string) {
  const dir = id === "nextjs" ? "next" : id;
  return startServer(
    {
      label: labels[id],
      command: nativeEngine(id)
        ? join(targetDirectory, "release", `framework-ssr-${id}`)
        : process.execPath,
      args: nativeEngine(id)
        ? []
        : id === "exact" && isShowcase(workload)
          ? [join(root, "benchmarks/rendering/showcase/full-exact-server.mjs")]
          : [
              join(
                here,
                "adapters",
                dir,
                id === "sveltekit" ? "server.ts" : "server.mjs",
              ),
            ],
      cwd: root,
    },
    {
      ...environment,
      PORT: String(portFor(id)),
      EXACT_SHOWCASE_WORKLOAD: workload,
    },
  );
}
async function ready(server: ReturnType<typeof startServer>, id: string) {
  const health = (await waitForHealth(server, portFor(id), agent)) as {
    engine: string;
    runtime?: string;
    framework: string;
    nodeEnv?: string;
    workerThreads?: number;
  };
  assert.equal(health.engine, id);
  if (nativeEngine(id)) {
    assert.equal(health.workerThreads, 1);
    if (id === "leptos") assert.equal(health.runtime, "Rust / Tokio");
  } else {
    assert.equal(health.nodeEnv, "production");
    assert.equal(health.runtime, contract.runtime);
  }
  return health;
}
async function response(id: string, request: string, workload: string) {
  const result = await fetchBody(
    portFor(id),
    `${workloadPath(workload)}?request=${encodeURIComponent(request)}`,
    agent,
    headers,
  );
  assert.equal(result.statusCode, 200);
  assert.match(
    String(result.headers["cache-control"]),
    /no-store/,
    "full-document cache must be disabled",
  );
  return result;
}
try {
  if (!noBuild) await (proaOnly ? buildProa() : buildAll());
  const source = await gitMetadata(root, sourceFiles);
  const captureId = newCaptureId("framework-ssr");
  const captureDirectory = join(
    resultsDirectory,
    smoke || parityOnly || proaOnly ? "local" : ".",
  );
  const raw = join(captureDirectory, "raw", captureId);
  await mkdir(raw, { recursive: true });
  const engines: Array<
    Capture["engines"][number] & {
      parity: {
        pass: boolean;
        semanticSha256: string;
        negativeControls: number;
        responseBytes: number;
      };
    }
  > = [];
  // Admit every engine/workload before timing. Each production app gets a fresh
  // process; Exact's showcase builds have separate native application manifests.
  for (const id of selectedEngines) {
    const parityByWorkload: NonNullable<
      Capture["engines"][number]["parityByWorkload"]
    > = {};
    let engineHealth: Awaited<ReturnType<typeof ready>> | undefined;
    for (const workload of activeWorkloads) {
      const key = workload.id;
      const server = serverFor(id, key);
      try {
        engineHealth = await ready(server, id);
        const options = { adapted: id === "exact" && isShowcase(key) };
        await response(id, "fresh-a", key);
        const first = await response(id, "fresh-b", key);
        const second = await response(id, "fresh-b", key);
        const semantic = validateSemanticHtml(
          first.body.toString(),
          "fresh-b",
          key,
          options,
        );
        assert.equal(
          sha256(first.body),
          sha256(second.body),
          "same-URL responses must be byte stable",
        );
        const controls = negativeControlsFor(key);
        for (const [from, to] of controls) {
          const changed = first.body.toString().replaceAll(from, to);
          assert.notEqual(changed, first.body.toString());
          assert.throws(
            () => validateSemanticHtml(changed, "fresh-b", key, options),
            "negative control must fail",
          );
        }
        const fresh = await response(id, "fresh-c", key);
        validateSemanticHtml(fresh.body.toString(), "fresh-c", key, options);
        await writeFile(
          join(raw, `${id}-${key}-parity.html.gz`),
          gzipSync(first.body, { level: 9 }),
        );
        parityByWorkload[key] = {
          pass: true,
          semanticSha256: semantic,
          negativeControls: controls.length,
          responseBytes: first.body.length,
          responseSha256: sha256(first.body),
          ...(id === "exact" && isShowcase(key)
            ? {
                adaptation: JSON.parse(
                  await readFile(
                    join(
                      root,
                      "benchmarks/rendering/showcase/.generated/exact",
                      key,
                      "adaptation.json",
                    ),
                    "utf8",
                  ),
                ),
              }
            : {}),
        };
        console.log(
          `${labels[id]}/${key}: production SSR parity, negative controls and freshness passed`,
        );
      } finally {
        await stopServer(server);
      }
    }
    assert.ok(engineHealth);
    engines.push({
      id,
      framework: engineHealth.framework,
      runtime: engineHealth.runtime || "Rust / Tokio",
      parity: parityByWorkload[activeWorkloads[0].id],
      parityByWorkload,
      phases: [] as Phase[],
    });
  }
  if (parityOnly) {
    console.log(
      `All ${selectedEngines.length * activeWorkloads.length} framework/workload admission cells passed; no timings collected.`,
    );
  } else {
    workers = await spawnWorkers(workersCount);
    for (const workload of activeWorkloads)
      for (const mode of ["closed", "open"] as const)
        for (let repeat = 1; repeat <= policy.repeats; repeat++) {
          const order = selectedEngines.map(
            (_, i) =>
              selectedEngines[(i + repeat - 1) % selectedEngines.length],
          );
          for (const id of order) {
            const engine = engines.find((e) => e.id === id);
            assert.ok(engine, `Missing admitted adapter: ${id}`);
            const server = serverFor(id, workload.id);
            try {
              await ready(server, id);
              const request = `${captureId}-${workload.id}-${mode}-${repeat}`;
              const expected = await response(id, request, workload.id);
              validateSemanticHtml(
                expected.body.toString(),
                request,
                workload.id,
                { adapted: id === "exact" && isShowcase(workload.id) },
              );
              for (let i = 0; i < policy.warmupRequests; i++)
                assert.equal(
                  sha256((await response(id, request, workload.id)).body),
                  sha256(expected.body),
                );
              const options: Parameters<typeof runClosedLoopPhase>[0] = {
                workers,
                server,
                port: portFor(id),
                path: `${workloadPath(workload.id)}?request=${encodeURIComponent(request)}`,
                headers,
                concurrency: smoke
                  ? policy.concurrency
                  : (workload.capacityConcurrency ?? policy.concurrency),
                rate: workload.fixedRateRps,
                preRollSeconds: policy.preRollSeconds,
                durationSeconds: smoke
                  ? policy.durationSeconds
                  : mode === "closed"
                    ? workload.capacityDurationSeconds
                    : (workload.latencyDurationSeconds ??
                      policy.durationSeconds),
                timeoutMs: policy.requestTimeoutMs,
                validatorModule: pathToFileURL(join(here, "parity.mjs")).href,
                validatorOptions: { expectedSha256: sha256(expected.body) },
                metricsAgent: agent,
              };
              const phase: Awaited<ReturnType<typeof runClosedLoopPhase>> =
                await (mode === "closed"
                  ? runClosedLoopPhase(options)
                  : runOpenLoopPhase(options));
              if (phase.errorCount || !phase.loadGeneratorValid)
                await writeFile(
                  join(raw, "rejected-phase.json"),
                  JSON.stringify(
                    {
                      engine: id,
                      workload: workload.id,
                      repeat,
                      phase,
                    },
                    null,
                    2,
                  ),
                );
              assert.equal(
                phase.errorCount,
                0,
                `${id} ${mode} request failures`,
              );
              if (!smoke)
                assert.equal(
                  phase.loadGeneratorValid,
                  true,
                  `${id} load generator limited`,
                );
              engine.phases.push({
                ...phase,
                repeat,
                workload: workload.id,
                requestValue: request,
                expectedResponseSha256: sha256(expected.body),
              });
              console.log(
                `${id}/${workload.id} ${mode} ${repeat}: ${phase.completionThroughputRps.toFixed(1)} responses/s; P99 ${phase.latencyMs.scheduledComplete.p99.toFixed(2)}ms`,
              );
            } finally {
              await stopServer(server);
            }
          }
        }
    const result = {
      schemaVersion: 2,
      status: "pass",
      captureKind: shardWorkload
        ? "shard"
        : smoke
          ? "smoke"
          : proaOnly
            ? "engineering"
            : "publication",
      ...(shardWorkload ? { shard: { workload: shardWorkload, smoke } } : {}),
      captureId,
      capturedAt: new Date().toISOString(),
      host: {
        ...hostMetadata(),
        cloud: process.env.BENCH_HOST_LABEL || null,
        serverCpu: process.env.BENCH_SERVER_CPU || null,
      },
      scenario: { ...contract, workloads: activeWorkloads },
      methodology: policy,
      source,
      engines,
      commands: {
        runtime: contract.runtime,
        build: "bun benchmarks/framework-ssr/build.ts",
        capture: "bun benchmarks/framework-ssr/run.ts",
      },
      limitations: [
        ...contract.limitations,
        ...(proaOnly
          ? [
              "Proa-only diagnostic; peer results were not rerun. This capture cannot replace the published comparison.",
            ]
          : []),
      ],
    } satisfies Capture;
    validateResult(result, !smoke && !proaOnly && !shardWorkload);
    await mkdir(join(here, "results"), { recursive: true });
    retainCapture(root, captureDirectory, result, sourceFiles);
    atomicWrite(output, `${JSON.stringify(result, null, 2)}\n`);
    atomicWrite(output.replace(/\.json$/, ".md"), renderReport(result));
    console.log(`Validated ${result.captureKind} capture: ${output}`);
  }
} finally {
  if (workers) await closeWorkers(workers);
  agent.destroy();
  await release();
}
